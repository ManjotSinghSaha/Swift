import Cocoa

// Question 1
func swap<T>(num1: inout T, num2: inout T){
    let num3 = num1
    num1 = num2
    num2 = num3
}

// Example - Passing integer values in swap function
var a = 11
var b = 22
swap(&a, &b)
print("After swapping, num1: ", a)
print("After swapping, num2: ", b)
print("\n")

// Example - Passing string values in swap function
var word1 = "Manjot"
var word2 = "Singh"
swap(&word1, &word2)
print("After swapping, num1: ", word1)
print("After swapping, num2: ", word2)
print("\n")

// Example - Passing double values in swap function
var double1 = 11.11
var double2 = 22.2222
swap(&double1, &double2)
print("After swapping, num1: ", double1)
print("After swapping, num2: ", double2)
print("\n")

//Question 2
func SumAvgArray(values:[Int]) -> (Int, Double){
    var intSum: Int = 0
    var doubleAvg: Double = 0.00
    for num in values {
        intSum += num
        doubleAvg = Double(intSum) / Double((values.count))
    }
    return (intSum, doubleAvg)
}

var array = [1,2,3,4,5,6,7,8,9,10]
print(SumAvgArray(values: array))
print("\n")

//Question 3
let tempReadings = [
    "Monday" : [12, 25, 10],
    "Tuesday" : [2, 15, 9],
    "Wednesday" : [11, 29, 22],
    "Thursday" : [7, 11, 9],
    "Friday" : [ 16, 22, 20]
]


var avgTempWeek:Double = 0.00
var totalCount:Int = 0

for(days, temperature) in tempReadings {
    var totalTemp: Double = 0.0
    var avgTempDay: Double = 0.00
    for num in temperature {
        totalTemp += Double(num)
        avgTempDay = totalTemp / Double(temperature.count)
    }
    
    //a
    print("Average Temperature For \(days) is: " + String(format: "%.2f", avgTempDay))
    //c
    print("Maximum temperature for \(days) is: ", temperature.max()!)
    print("\n")
    
    avgTempWeek += Double(totalTemp)
    totalCount += Int(temperature.count)
}

//b
print("Average Temperature of the week is: " + String(format: "%.2f", avgTempWeek / Double(totalCount)))
print("\n")


//Question 4
var stockValues = [30.50, 10.25, 60.75, 100.25, 45.45, 89.60, 20.50, 55.55, 90.0, 70.0]

func ModifyStockValues(values: inout [Double]) {
        for i in 0 ..< values.count{
            values[i] += 10.00
        }
    }

print("Original Array: " + stockValues.description)
ModifyStockValues(values: &stockValues)
print("Modified Array: " + stockValues.description, "\n")

// b
func ModifyStockElements(element: inout Double){
    element += 10.00
}

print("Before Modification: \(stockValues[0])")
ModifyStockElements(element: &stockValues[0])
print("After Modification: \(stockValues[0])")
